import bpy
import os
import math
import mathutils
from mathutils import Vector, Matrix
import binascii
import struct
import array
from bpy.props import *
from bpy_extras.io_utils import (
        ImportHelper,
        ExportHelper,
        orientation_helper,
        path_reference_mode,
        axis_conversion,
        unpack_list,
        )
from bpy.types import (
        Operator,
        OperatorFileListElement,
        )



error_message = ""

prop = {}



class DialogOperator(Operator):
    bl_idname = "object.dialog_operator"
    bl_label = "A problem occurred."
    def execute(self, context):
        self.report({'ERROR'}, error_message)
        return {'FINISHED'}
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)


class Float16Compressor:
    def __init__(self):
        self.temp = 0

    def compress(self,float32):
        F16_EXPONENT_BITS = 0x1F
        F16_EXPONENT_SHIFT = 10
        F16_EXPONENT_BIAS = 15
        F16_MANTISSA_BITS = 0x3ff
        F16_MANTISSA_SHIFT =  (23 - F16_EXPONENT_SHIFT)
        F16_MAX_EXPONENT =  (F16_EXPONENT_BITS << F16_EXPONENT_SHIFT)

        a = struct.pack('>f',float32)
        b = binascii.hexlify(a)

        f32 = int(b,16)
        f16 = 0
        sign = (f32 >> 16) & 0x8000
        exponent = ((f32 >> 23) & 0xff) - 127
        mantissa = f32 & 0x007fffff
                
        if exponent == 128:
            f16 = sign | F16_MAX_EXPONENT
            if mantissa:
                f16 |= (mantissa & F16_MANTISSA_BITS)
        elif exponent > 15:
            f16 = sign | F16_MAX_EXPONENT
        elif exponent > -15:
            exponent += F16_EXPONENT_BIAS
            mantissa >>= F16_MANTISSA_SHIFT
            f16 = sign | exponent << F16_EXPONENT_SHIFT | mantissa
        else:
            f16 = sign
        return f16

    def decompress(self,float16):
        s = int((float16 >> 15) & 0x00000001)    # sign
        e = int((float16 >> 10) & 0x0000001f)    # exponent
        f = int(float16 & 0x000003ff)            # fraction

        if e == 0:
            if f == 0:
                return int(s << 31)
            else:
                while not (f & 0x00000400):
                    f = f << 1
                    e -= 1
                e += 1
                f &= ~0x00000400
        elif e == 31:
            if f == 0:
                return int((s << 31) | 0x7f800000)
            else:
                return int((s << 31) | 0x7f800000 | (f << 13))

        e = e + (127 -15)
        f = f << 13
        return int((s << 31) | (e << 23) | f)


fglb = {'ENDIAN':"<"}#'file' = filehandle
def fread(offset = -1, fmt = 'L', extractifsingle = True):
    global fglb
    if type(offset) is str:
        if type(fmt) is bool:
            extractifsingle = fmt
        fmt = offset
    elif offset != -1:
        fglb['FILE'].seek(offset)
    result = struct.unpack(fglb['ENDIAN'] + fmt, fglb['FILE'].read(struct.calcsize("!"+fmt)))
    if extractifsingle and len(result) == 1:
        return result[0]
    return result

def freadstring(offset = -1, maxbytes = 255):
    global fglb
    if offset != -1:
        fglb['FILE'].seek(offset)
    mahbytes = b''
    count = 0
    while True:
        count += 1
        chr = fglb['FILE'].read(1)
        mahbytes += chr
        if len(chr) == 0 or count == maxbytes:
            return mahbytes[:].decode('ASCII')
        elif mahbytes[-1] == 0:
            return mahbytes[:-1].decode('ASCII')


class TMCHead():
    global fglb
    name = ''
    Size = Count1 = Count2 = Offset1 = Offset2 = Offset3 = base = 0
    offsets = []
    sizes = []
    def __init__(self, base):
        fglb['FILE'].seek(base)
        self.name = freadstring(base)
        if fread(base + 8, 'L') !=  0x01010000:
            return

        self.Size, self.Count1, self.Count2, self.Count3, self.Offset1, self.Offset2, self.Offset3 = fread(base + 0x10, '7L')
        self.base = base
        fglb['FILE'].seek(base + self.Offset1)
        self.offsets = [fread('L') for i in range(self.Count1)]
        if self.Offset2 != 0:
            fglb['FILE'].seek(base + self.Offset2)
            self.sizes = [fread('L') for i in range(self.Count1)]


class TMCMeshData():
    fvfdata = []
    vertices = []
    normals = []
    blend_weights = []
    blend_indices = []
    v_colors = []
    tangents = []
    bitangent_signs = []
    uvs = []

    indices = []
    blendidx = {}
    blendname = []
    colors = []

    vsize = vcount = icount = uvcount = 0
    fcomp = Float16Compressor()
    gmatrix = mathutils.Matrix()

    def parseFVFData(self, base, count):
        fglb['FILE'].seek(base)
        self.fvfdata = []
        for i in range(count):
            data = FVFData()
            self.fvfdata.append(data)

    def parseVertices(self, base):
        self.vertices = []
        self.normals = []
        self.blend_weights = []
        self.blend_indices = []
        self.v_colors = []
        self.tangents = []
        self.bitangent_signs = []
        self.uvs = []
        for vindex in range(self.vcount):
            uv = []
            for i in range(len(self.fvfdata)):
                fglb['FILE'].seek(base + (self.vsize * vindex) + self.fvfdata[i].Offset)
                if self.fvfdata[i].Usage == 0:
                    self.vertices.append(list(fread('3f')))
                elif self.fvfdata[i].Usage == 3:
                    self.normals.append(list(fread('3f')))
                elif self.fvfdata[i].Usage == 1:
                    if self.fvfdata[i].Type == 3:
                        self.blend_weights.append(list(fread('4f')))
                    else:
                        self.blend_weights.append(list(fread('4B')))
                elif self.fvfdata[i].Usage == 2:
                    self.blend_indices.append(list(fread('4B')))
                elif self.fvfdata[i].Usage == 10:
                    self.v_colors.append(list(fread('4B')))
                elif self.fvfdata[i].Usage == 6:
                    self.tangents.append(list(fread('3f')))
                    self.bitangent_signs.append(fread('f'))
                elif self.fvfdata[i].Usage == 5:
                    if self.fvfdata[i].Type == 0xB:
                        uv.append(self.parseUV())
                        uv.append(self.parseUV())
                    else:
                        uv.append(self.parseUV())
            self.uvs.append(uv)

        for i in range(len(self.fvfdata)):
            if self.fvfdata[i].Usage == 5 and self.fvfdata[i].Type == 0xB:
                self.uvcount += 2
            elif self.fvfdata[i].Usage == 5 and self.fvfdata[i].Type == 0xA:
                self.uvcount += 1

    def parseUV(self):
        uv = []
        h = fread('H')
        str = struct.pack('I',self.fcomp.decompress(h))
        f = struct.unpack('f',str)[0]
        uv.append(f)
        h = fread('H')
        str = struct.pack('I',self.fcomp.decompress(h))
        f = struct.unpack('f',str)[0]
        uv.append(1 - f)
        return uv

    def parseIndices(self, base):
        fglb['FILE'].seek(base)
        self.indices = fread(str(self.icount) + 'H')

    def parseMatrix(self, base):
        fglb['FILE'].seek(base)
        self.gmatrix = Matrix([fread("4f") for i in range(4)]).transposed()

    def parseBlendIdx(self, base):
        fglb['FILE'].seek(base)
        self.blendidx = {}
        self.blendname = []
        blendIdxH = TMCHead(base)
        for i in range(blendIdxH.Count1):
            idx = fread(base + blendIdxH.offsets[i], 'L')
            len = fread('L')
            name = freadstring(base + blendIdxH.offsets[i] + 0x10, len)
            self.blendidx[idx] = i
            self.blendname.append(name)

    def parseMtrCol(self, base):
        fglb['FILE'].seek(base)
        self.colors = []
        for i in range(12):
            color = fread("4f")
            self.colors.append(color)


class FVFData():
    Offset = Type = Usage = Layer = 0
    def __init__(self):
        self.Offset, self.Type, self.Usage, self.Layer = fread('2xBxBx2B')





def import_tmcmesh(filepath):

    with open(filepath, 'rb') as f:

        fglb['FILE'] = f

        tmcH = TMCHead(0)
        if tmcH.name != "tmcmesh":
            return

        geoH = TMCHead(tmcH.offsets[0])

        meshdata = TMCMeshData()

        FVFDataCount = fread(geoH.base + geoH.offsets[0] + 8, 'L')
        meshdata.parseFVFData(geoH.base + geoH.offsets[0] + 0x10, FVFDataCount)

        meshdata.vsize = fread(geoH.base + geoH.offsets[0] + 4, 'L')
        meshdata.vcount = fread(geoH.base + geoH.offsets[1] + 0x7C, 'L')
        meshdata.icount = fread(geoH.base + geoH.offsets[1] + 0x74, 'L')

        meshdata.parseVertices(tmcH.offsets[2])
        meshdata.parseIndices(tmcH.offsets[3])
        if tmcH.offsets[4] != 0: meshdata.parseMtrCol(tmcH.offsets[4])
        if tmcH.offsets[9] != 0: meshdata.parseMatrix(tmcH.offsets[9])
        meshdata.parseBlendIdx(tmcH.offsets[15])

        filename = os.path.splitext((os.path.basename(filepath)))[0]
        meshname = filename
        tempnames = filename.split("-")
        if len(tempnames) > 1:
            meshname = tempnames[1].strip()

        faces = []
        clockwise = True
        for i in range(len(meshdata.indices) - 2):
            if len(meshdata.indices[i:i+3]) != len(set(meshdata.indices[i:i+3])):
                clockwise = not clockwise
                continue
            if clockwise:
                faces.append((meshdata.indices[i:i+3]))
            else:
                faces.append((meshdata.indices[i], meshdata.indices[i+2], meshdata.indices[i+1]))
            clockwise = not clockwise

        mesh = bpy.data.meshes.new(meshname)
        mesh.from_pydata(meshdata.vertices, [], faces)
        mesh.update()

        if len(meshdata.v_colors) > 0:
            color_layer = mesh.vertex_colors.new(name="Color")
            alpha_layer = mesh.vertex_colors.new(name="Alpha")
            for poly in mesh.polygons:
                for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
                    col = meshdata.v_colors[mesh.loops[loop_index].vertex_index]
                    color_layer.data[loop_index].color = [col[0]/255, col[1]/255, col[2]/255]
                    alpha_layer.data[loop_index].color = [col[3]/255, col[3]/255, col[3]/255]

        for i in range(meshdata.uvcount):
            mesh.uv_layers.new(name="UV Maps %d" % (i + 1))
            for poly in mesh.polygons:
                for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
                    mesh.uv_layers[i].data[loop_index].uv = meshdata.uvs[mesh.loops[loop_index].vertex_index][i]

        mesh.polygons.foreach_set("use_smooth", [True] * len(mesh.polygons))

        view_layer = bpy.context.view_layer
        if view_layer.objects.active != None:
            hidden = False
            if view_layer.objects.active.hide_viewport:
                view_layer.objects.active.hide_viewport = False
                hidden = True
            if view_layer.objects.active.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
            if hidden:
                view_layer.objects.active.hide_viewport = True
            for ob in bpy.context.selected_objects:
                ob.select_set(False)
        obj = bpy.data.objects.new(meshname, mesh)
        bpy.context.scene.collection.objects.link(obj)
        view_layer.objects.active = obj
        obj.select_set(True)

        global_matrix = axis_conversion(to_forward='Z', to_up='-Y').to_4x4()

        if prop["transform_matrix"]  and tmcH.offsets[9] != 0:
            obj.matrix_world = global_matrix
            for v, n in zip(mesh.vertices, meshdata.normals):
                v.normal = Vector(n) @ meshdata.gmatrix.inverted_safe()
            mesh.transform(meshdata.gmatrix)
        else:
            if tmcH.offsets[9] != 0:
                global_matrix = global_matrix @ meshdata.gmatrix
            obj.matrix_world = global_matrix
            mesh.vertices.foreach_set("normal", unpack_list(meshdata.normals))

        for i in range(len(meshdata.blendname)):
            groupname = change_nodename(meshdata.blendname[i])
            obj.vertex_groups.new(name=groupname)

        if tmcH.offsets[4] != 0 and prop["apply_material"]:
            mat = bpy.data.materials.new(meshname)
            mat.diffuse_color  = (meshdata.colors[1][0], meshdata.colors[1][1], meshdata.colors[1][2], 0)
            mat.specular_color = meshdata.colors[2][0:3]
            mat.specular_intensity = sum(meshdata.colors[2][0:3]) / 3
            mat.roughness = 1 / meshdata.colors[2][3] * 5

            mesh.materials.append(mat)

        view_layer.objects.active = obj

        if len(meshdata.blend_indices) != 0:
            if isinstance(meshdata.blend_weights[0][0], float):
                for i in range(len(meshdata.blend_indices)):
                    for j in range(4):
                        if meshdata.blend_weights[i][j] == 0:
                            continue
                        obj.vertex_groups[meshdata.blendidx[meshdata.blend_indices[i][j]]].add([i], meshdata.blend_weights[i][j], 'REPLACE')
            else:
                blendbase = 1 / 255
                for i in range(len(meshdata.blend_indices)):
                    for j in range(4):
                        if meshdata.blend_weights[i][j] == 0:
                            continue
                        if meshdata.blend_weights[i][j] == 0xFF:
                            weight = 1.0
                        else:
                            weight = blendbase * meshdata.blend_weights[i][j]
                        obj.vertex_groups[meshdata.blendidx[meshdata.blend_indices[i][j]]].add([i], weight, 'REPLACE')
        else:
            v_group = obj.vertex_groups.new(obj.name)
            for i in range(len(mesh.vertices)):
                v_group.add([i], 1.0, 'REPLACE')

        bpy.ops.object.vertex_group_sort(sort_type='NAME')

        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        if space.overlay.normals_length >= 0.1:
                            space.overlay.normals_length = 0.01
                        break
                break


def change_nodename(nodename):
    s = nodename

    if s == "MOT18_right_upleg_MobA_Tiger":
        return "MOT_*_leg_MobA_Tiger.1.r"
    elif s == "MOT19_right_shin_MobA_Tiger":
        return "MOT_*_foot_MobA_Tiger.1.r"
    elif s == "MOT20_right_foot_MobA_Tiger":
        return "MOT_*_toe_MobA_Tiger.1.r"

    if "_Instance" in s:
        s = s.replace("_Instance", ">")
    if ">" not in s and s[:3] == "MOT" and ("Right" in s or "Left" in s or "right" in s or "left" in s):
        if s[4] == "_":
            s = "MOT_" + s[5:]
        else:
            s = "MOT" + s[5:]
    if "Right" in s:
        s = s.replace("Right", "*") + ".1.R"
    elif "Left" in s:
        s = s.replace("Left", "*") + ".1.L"
    elif "right" in s:
        s = s.replace("right", "*") + ".1.r"
    elif "left" in s:
        s = s.replace("left", "*") + ".1.l"
    elif "_R_" in s:
        s = s.replace("_R_", "_*_") + ".0.R"
    elif "_L_" in s:
        s = s.replace("_L_", "_*_") + ".0.L"
    elif "_r_" in s:
        s = s.replace("_r_", "_*_") + ".0.r"
    elif "_l_" in s:
        s = s.replace("_l_", "_*_") + ".0.l"
    else:
        s = s

    return s




class Import_tmcmesh(Operator, ImportHelper):
    """Import to tmcmesh"""
    bl_idname = "import.tmcmesh"
    bl_label = "Import tmcmesh"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".tmcmesh"

    filter_glob: StringProperty(
            default="*.tmcmesh",
            options={'HIDDEN'},
            )

    files: CollectionProperty(
            name="File Path",
            type=OperatorFileListElement,
            )

    transform_matrix: BoolProperty(
            name="Transform by Matrix Data",
            description="Transform by Matrix data",
            default=False,
            )

    apply_material: BoolProperty(
            name="Apply Material",
            description="Apply Material",
            default=True,
            )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "transform_matrix")
        layout.prop(self, "apply_material")

    def execute(self, context):
        global prop

        prop = {}
        prop["transform_matrix"] = self.transform_matrix
        prop["apply_material"] = self.apply_material

        dirpath = os.path.dirname(self.filepath)

        for file in self.files:
            import_tmcmesh(dirpath + "\\" + file.name)
        if len(self.files) == 0:
            import_tmcmesh(self.filepath)

        return {"FINISHED"}
