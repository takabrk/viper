
bl_info = {
    "name": "Import-Export tmcmesh (.tmcmesh)",
    "author": "dtk mnr",
    "version": (1, 0, 4),
    "blender": (2, 80, 0),
    "location": "File > Import-Export",
    "description": "Import-Export tmcmesh",
    "warning": "",
    "category": "Import-Export",
}

if "bpy" in locals():
    import importlib
    if "import_tmcmesh" in locals():
        importlib.reload(import_tmcmesh)
    if "export_tmcmesh" in locals():
        importlib.reload(export_tmcmesh)
else:
    from . import import_tmcmesh
    from . import export_tmcmesh

import bpy
import gc
import os
import bmesh

def menu_func_import(self, context):
    self.layout.operator(import_tmcmesh.Import_tmcmesh.bl_idname, text="tmcmesh (.tmcmesh)", icon='PLUGIN')

def menu_func_export(self, context):
    mesh_exist = False
    for obj in bpy.context.selected_objects:
        if obj.hide_viewport or obj.type != 'MESH' or len(obj.data.uv_layers) == 0:
            continue
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh()
        v_count = len(mesh.vertices)
        obj_eval.to_mesh_clear()
        if len(obj.data.polygons) == 0 or v_count > 65534:
            continue
        mesh_exist = True
        default_path = obj.name + ".tmcmesh"

    if not mesh_exist:
        return {'CANCELLED'}
    self.layout.operator(export_tmcmesh.Export_tmcmesh.bl_idname, text="tmcmesh (.tmcmesh)", icon='PLUGIN').filepath = default_path

    gc.collect()


classes = (
    import_tmcmesh.Import_tmcmesh,
    export_tmcmesh.Export_tmcmesh,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)

if __name__=="__main__":
    register()
