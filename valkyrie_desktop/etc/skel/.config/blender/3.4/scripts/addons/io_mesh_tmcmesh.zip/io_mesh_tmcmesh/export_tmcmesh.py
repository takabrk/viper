import bpy
import gc
import os
import math
import mathutils
import binascii
import struct
import bmesh
import re
from operator import attrgetter
from bpy.props import *
from bpy_extras.io_utils import (
        ImportHelper,
        ExportHelper,
        orientation_helper,
        axis_conversion,
        )
from bpy.types import (
        Operator,
        OperatorFileListElement,
        )

# Enable Secret Option
ignore_different_tangent_option = False



exportable_objects = []
error_message = ""
prop = {}



class Float16Compressor:
    def __init__(self):
        self.temp = 0

    def compress(self,float32,round):
        F16_EXPONENT_BITS = 0x1F
        F16_EXPONENT_SHIFT = 10
        F16_EXPONENT_BIAS = 15
        F16_MANTISSA_BITS = 0x3ff
        F16_MANTISSA_SHIFT =  (23 - F16_EXPONENT_SHIFT)
        F16_MAX_EXPONENT =  (F16_EXPONENT_BITS << F16_EXPONENT_SHIFT)

        a = struct.pack('>f',float32)
        b = binascii.hexlify(a)

        f32 = int(b,16)
        f16 = 0
        sign = (f32 >> 16) & 0x8000
        exponent = ((f32 >> 23) & 0xff) - 127
        mantissa = f32 & 0x007fffff
                
        if exponent == 128:
            f16 = sign | F16_MAX_EXPONENT
            if mantissa:
                f16 |= (mantissa & F16_MANTISSA_BITS)
        elif exponent > 15:
            f16 = sign | F16_MAX_EXPONENT
        elif exponent > -15:
            exponent += F16_EXPONENT_BIAS
            if round:
                F16_MANTISSA_OFFSET = 1 << ( F16_MANTISSA_SHIFT - 1)
                mantissa = (mantissa + F16_MANTISSA_OFFSET) >> F16_MANTISSA_SHIFT
                f16 = sign | (exponent << F16_EXPONENT_SHIFT) + mantissa
            else:
                mantissa >>= F16_MANTISSA_SHIFT
                f16 = sign | exponent << F16_EXPONENT_SHIFT | mantissa
        else:
            f16 = sign
        return f16

    def decompress(self,float16):
        s = int((float16 >> 15) & 0x00000001)    # sign
        e = int((float16 >> 10) & 0x0000001f)    # exponent
        f = int(float16 & 0x000003ff)            # fraction

        if e == 0:
            if f == 0:
                return int(s << 31)
            else:
                while not (f & 0x00000400):
                    f = f << 1
                    e -= 1
                e += 1
                f &= ~0x00000400
        elif e == 31:
            if f == 0:
                return int((s << 31) | 0x7f800000)
            else:
                return int((s << 31) | 0x7f800000 | (f << 13))

        e = e + (127 -15)
        f = f << 13
        return int((s << 31) | (e << 23) | f)


class NewVertex():
    __slots__ = (
        "ori_id",
        "co",
        "normal",
        "blend_weights",
        "blend_indices",
        "v_color",
        "tangent",
        "bitangent_sign",
        "uv"
        )

    def __init__(self, mesh, mesh_vg, index):

        global prop

        self.ori_id = mesh.loops[index].vertex_index
        self.co = list(mesh.vertices[self.ori_id].co)
        if prop["use_loop_normals_mesh"]:
            self.normal = list(mesh.loops[index].normal)
        else:
            self.normal = list(mesh.vertices[self.ori_id].normal)
        self.set_blend(mesh_vg, self.ori_id)
        self.v_color = []
        self.set_v_color(mesh, index)
        self.tangent = list(mesh.loops[index].tangent)
        self.bitangent_sign = mesh.loops[index].bitangent_sign
        self.uv = []
        for uv_index in prop["assign_uv"]:
            self.uv.append(list(mesh.uv_layers[uv_index].data[index].uv))

    def set_blend(self, mesh, index):

        global prop

        self.blend_indices = [0, 0, 0, 0]
        if prop["v_datasize"] == 1:
            self.blend_weights = [1.0, 0, 0, 0]
        else:
            self.blend_weights = [255, 0, 0, 0]

        if len(mesh.vertices[index].groups) != 0:
            sortedgroups = sorted(mesh.vertices[index].groups, key=attrgetter('weight'), reverse=True)
            if len(mesh.vertices[index].groups) > 4:
                vgroups = sortedgroups[:4]
            else:
                vgroups = list(sortedgroups)
            for g in vgroups:
                if g.weight < 0:
                    g.weight = 0
            total = math.fsum(g.weight for g in vgroups)
            if total == 0:
                self.blend_indices[0] = prop["assign_zero_weight"]
            else:
                weights = []
                total_weights = 0
                if prop["v_datasize"] == 1:
                    for g in vgroups:
                        weight = g.weight * 1 / total
                        weights.append(weight)
                        total_weights += weight
                    weights[0] += 1 - total_weights
                else:
                    for g in vgroups:
                        weight = round(g.weight * 255 / total)
                        weights.append(weight)
                        total_weights += weight
                    weights[0] += 255 - total_weights
                for i in range(len(vgroups)):
                    self.blend_weights[i] = weights[i]
                    self.blend_indices[i] = vgroups[i].group

    def set_v_color(self, mesh, index):

        global prop

        if prop["v_datasize"] != 2:
            return

        if "Color" in mesh.vertex_colors:
            color = mesh.vertex_colors["Color"].data[index].color
            self.v_color.extend([round(color[0] * 255), round(color[1] * 255), round(color[2] * 255)])
        else:
            self.v_color.extend([255, 255, 255])

        if "Alpha" in mesh.vertex_colors:
            alpha = mesh.vertex_colors["Alpha"].data[index].color
            self.v_color.append(round((alpha[0] + alpha[1] + alpha[2]) / 3 * 255))
        else:
            self.v_color.append(255)


class ErrorDialogOperator(Operator):
    bl_idname = "object.error_dialog_operator"
    bl_label = "A problem occurred."
    def execute(self, context):
        self.report({'ERROR'}, error_message)
        return {'FINISHED'}
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)



def build_vertex_data(me, me_vg, ori_normals, mat_index):

    global error_message
    global prop

   
    new_vertices = [] # 新頂点配列
    convert_vertex = [] # 新旧頂点インデックス変換配列
    new_faces = [] # 新面配列

    if len(ori_normals) == len(me.vertices) and not prop["use_loop_normals_mesh"]:
        for i in range(len(ori_normals)):
            me.vertices[i].normal = list(ori_normals[i])

    me.calc_tangents(uvmap=me.uv_layers[prop["assign_uv"][prop["normalmap"]]].name)

    uv_dict = {}
    for i, uv_index in enumerate(prop["assign_uv"]):
        if uv_index not in uv_dict.values():
            uv_dict[i] = uv_index

    for poly in me.polygons:
        vertex_array = []

        if mat_index != -1 and poly.material_index != mat_index:
            continue

        for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):

            loop = me.loops[loop_index]
            vertex_index = loop.vertex_index

            if vertex_index in convert_vertex:
                uv_count = 0
                converted_index = []
                for i, uv_index in uv_dict.items():
                    idx = -1
                    while idx+1 < len(convert_vertex) and vertex_index in convert_vertex[idx+1:]:
                        idx = convert_vertex.index(vertex_index, idx+1)
                        if new_vertices[idx].uv[i] == list(me.uv_layers[uv_index].data[loop_index].uv) and (new_vertices[idx].bitangent_sign == loop.bitangent_sign or prop["ignore_different_tangent"]) and (not prop["use_loop_normals_mesh"] or new_vertices[idx].normal == list(loop.normal)):
                            converted_index.append(idx)
                            break
                converted_index_set = set(converted_index)
                if len(converted_index) < len(uv_dict) or len(converted_index_set) > 1:
                    vertex_array.append(len(convert_vertex))
                    convert_vertex.append(vertex_index)
                    new_vertices.append(NewVertex(me, me_vg, loop_index))
                else:
                    vertex_array.append(converted_index[0])
            else:
                vertex_array.append(len(convert_vertex))
                convert_vertex.append(vertex_index)
                new_vertices.append(NewVertex(me, me_vg, loop_index))

        new_faces.append(vertex_array)

    me.free_tangents()

    if len(ori_normals) == len(me.vertices) and not prop["use_loop_normals_mesh"]:
        for i in range(len(new_vertices)):
            new_vertices[i].normal = list(ori_normals[new_vertices[i].ori_id])

    max_len = 65534
    if len(new_vertices) > max_len:
        error_message += me.name + " " + str(len(new_vertices) - max_len) + " vertices exceeded the maximum number.\n"
        return None, None

    return new_vertices, new_faces


def build_index_buffer(new_faces):

    global error_message

    index_buffer = []
    first_triangle = []

    remaining_faces = list(new_faces)

    for idx in remaining_faces[0]:
        first_triangle.append(idx)
    del remaining_faces[0]

    while len(remaining_faces) > 0:
        patern_A = -1
        patern_B = -1
        patern_C = -1
        patern_D = -1
        patern_D_index = -1

        if len(first_triangle) != 0:
            before = [first_triangle[0], first_triangle[1], first_triangle[2]]
        else:
            count = len(index_buffer) - 3
            before = [index_buffer[count], index_buffer[count + 1], index_buffer[count + 2]]

        for i in range(len(remaining_faces)):
            if patern_A == -1 and before[1] in remaining_faces[i] and before[2] in remaining_faces[i]:
                patern_A = i
                break
            elif patern_B == -1 and len(first_triangle) != 0 and before[0] in remaining_faces[i] and before[2] in remaining_faces[i]:
                patern_B = i
            elif patern_C == -1 and len(first_triangle) != 0 and before[0] in remaining_faces[i] and before[1] in remaining_faces[i]:
                patern_C = i
            elif patern_D == -1:
                if len(first_triangle) != 0 and before[0] in remaining_faces[i]:
                    patern_D = i
                    patern_D_index = before[0]
                elif len(first_triangle) != 0 and before[1] in remaining_faces[i]:
                    patern_D = i
                    patern_D_index = before[1]
                elif before[2] in remaining_faces[i]:
                    patern_D = i
                    patern_D_index = before[2]
            elif patern_A != -1 and patern_B != -1 and patern_C != -1 and patern_D != -1:
                break

        if len(first_triangle) != 0:
            if patern_A != -1:
                for idx in remaining_faces[patern_A]:
                    if idx != before[1] and idx != before[2]:
                        if len(index_buffer) != 0:
                            if len(index_buffer) % 2 == 1:
                                index_buffer.append(before[0])
                            elif len(index_buffer) % 2 == 0:
                                index_buffer.extend([before[0], before[0]])
                        index_buffer.extend([before[0], before[1], before[2], idx])
                        break
                del remaining_faces[patern_A]
                first_triangle = []

            elif patern_B != -1:
                for idx in remaining_faces[patern_B]:
                    if idx != before[0] and idx != before[2]:
                        if len(index_buffer) != 0:
                            if len(index_buffer) % 2 == 1:
                                index_buffer.append(before[1])
                            elif len(index_buffer) % 2 == 0:
                                index_buffer.extend([before[1], before[1]])
                        index_buffer.extend([before[1], before[2], before[0], idx])
                        break
                del remaining_faces[patern_B]
                first_triangle = []

            elif patern_C != -1:
                for idx in remaining_faces[patern_C]:
                    if idx != before[0] and idx != before[1]:
                        if len(index_buffer) != 0:
                            if len(index_buffer) % 2 == 1:
                                index_buffer.append(before[2])
                            elif len(index_buffer) % 2 == 0:
                                index_buffer.extend([before[2], before[2]])
                        index_buffer.extend([before[2], before[0], before[1], idx])
                        break
                del remaining_faces[patern_C]
                first_triangle = []

            else:
                if len(index_buffer) != 0:
                    if len(index_buffer) % 2 == 1:
                        index_buffer.append(before[0])

                    elif len(index_buffer) % 2 == 0:
                        index_buffer.extend([before[0], before[0]])

                index_buffer.extend([before[0], before[1], before[2], before[2]])

                first_triangle = [remaining_faces[0][0], remaining_faces[0][1], remaining_faces[0][2]]

                del remaining_faces[0]

        else:
            if patern_A != -1:
                for idx in remaining_faces[patern_A]:
                    if idx != before[1] and idx != before[2]:
                        index_buffer.append(idx)
                        break
                del remaining_faces[patern_A]

            elif patern_D != -1:
                if len(index_buffer) % 2 == 1:
                    index_buffer.extend([index_buffer[len(index_buffer) - 1], index_buffer[len(index_buffer) - 1]])

                elif len(index_buffer) % 2 == 0:
                    index_buffer.append(index_buffer[len(index_buffer) - 1])

                this_index = []
                if patern_D_index == remaining_faces[patern_D][0]:
                    index_buffer.extend([remaining_faces[patern_D][1], remaining_faces[patern_D][2]])
                elif patern_D_index == remaining_faces[patern_D][1]:
                    index_buffer.extend([remaining_faces[patern_D][2], remaining_faces[patern_D][0]])
                else:
                    index_buffer.extend([remaining_faces[patern_D][0], remaining_faces[patern_D][1]])

                del remaining_faces[patern_D]

            else:
                index_buffer.append(index_buffer[len(index_buffer) - 1])

                first_triangle = [remaining_faces[0][0], remaining_faces[0][1], remaining_faces[0][2]]

                del remaining_faces[0]


    if len(first_triangle) != 0:
        if len(index_buffer) % 2 == 1:
            index_buffer.extend([first_triangle[0], first_triangle[0], first_triangle[1], first_triangle[2]])
        elif len(index_buffer) % 2 == 0:
            index_buffer.extend([first_triangle[0], first_triangle[0], first_triangle[0], first_triangle[1], first_triangle[2]])

    return index_buffer


def build_bin_vertex_buffer(new_vertices):

    global prop

    part_bin = bytearray()
    fcomp = Float16Compressor()

    if prop["v_datasize"] == 1:
        for vtx in new_vertices:
            part_bin.extend(struct.pack("<4f", vtx.co[0], vtx.co[1], vtx.co[2], 1))
            part_bin.extend(struct.pack("<4f", vtx.normal[0], vtx.normal[1], vtx.normal[2], 0))
            part_bin.extend(struct.pack("<4f", vtx.blend_weights[0], vtx.blend_weights[1], vtx.blend_weights[2], vtx.blend_weights[3]))
            part_bin.extend(vtx.blend_indices)
            part_bin.extend(struct.pack("<3L", 0, 0, 0))
            part_bin.extend(set_common_vertex_data(fcomp, vtx))
    elif prop["v_datasize"] == 2:
        for vtx in new_vertices:
            part_bin.extend(struct.pack("<3f", vtx.co[0], vtx.co[1], vtx.co[2]))
            part_bin.extend(struct.pack("<3f", vtx.normal[0], vtx.normal[1], vtx.normal[2]))
            part_bin.extend(vtx.blend_weights)
            part_bin.extend(vtx.blend_indices)
            part_bin.extend(vtx.v_color)
            part_bin.extend(set_common_vertex_data(fcomp, vtx))
    else:
        for vtx in new_vertices:
            part_bin.extend(struct.pack("<3f", vtx.co[0], vtx.co[1], vtx.co[2]))
            part_bin.extend(struct.pack("<3f", vtx.normal[0], vtx.normal[1], vtx.normal[2]))
            part_bin.extend(vtx.blend_weights)
            part_bin.extend(vtx.blend_indices)
            part_bin.extend(set_common_vertex_data(fcomp, vtx))

    return part_bin


def set_common_vertex_data(fcomp, vtx):

    global prop

    bin = bytearray()

    bin.extend(struct.pack("<4f", vtx.tangent[0], vtx.tangent[1], vtx.tangent[2], vtx.bitangent_sign))
    u = [0, 0, 0, 0]
    v = [0, 0, 0, 0]
    for i in range(len(vtx.uv)):
        u[i] = fcomp.compress(vtx.uv[i][0], prop["round_uv_co"])
        v[i] = fcomp.compress(1 - vtx.uv[i][1], prop["round_uv_co"])
    bin.extend(struct.pack("<8H", u[0], v[0], u[1], v[1], u[2], v[2], u[3], v[3]))

    return bin


def build_bin_index_buffer(index_buffer):

    part_bin = bytearray()

    if len(index_buffer) % 8 != 0:
        for i in range(8 - (len(index_buffer) % 8)):
            index_buffer.append(0)

    for i in index_buffer:
        part_bin.extend(i.to_bytes(2, 'little'))

    return part_bin


def build_bin_geo(convert_vertex, index_buffer):

    global prop

    part_bin = bytearray()

    geo_header = [0x47, 0x65, 0x6F, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
                  0x60, 1, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0,
                  0x30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0x40, 0, 0, 0, 0x90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    if prop["v_datasize"] == 1:
        fvfdata = [0, 0, 0, 0, 0x60, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0x00, 0, 0x03, 0, 0, 0, 0, 0, 0x10, 0, 0x03, 0, 3, 0,
                   0, 0, 0x20, 0, 0x03, 0, 1, 0, 0, 0, 0x30, 0, 0x05, 0, 2, 0,
                   0, 0, 0x40, 0, 0x03, 0, 6, 0, 0, 0, 0x50, 0, 0x0B, 0, 5, 0,
                   0, 0, 0x58, 0, 0x0B, 0, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0]
    elif prop["v_datasize"] == 2:
        fvfdata = [0, 0, 0, 0, 0x44, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0x00, 0, 0x02, 0, 0, 0, 0, 0, 0x0C, 0, 0x02, 0, 3, 0,
                   0, 0, 0x18, 0, 0x0D, 0, 1, 0, 0, 0, 0x1C, 0, 0x05, 0, 2, 0,
                   0, 0, 0x20, 0, 0x0D, 0, 0x0A, 0, 0, 0, 0x24, 0, 0x03, 0, 6, 0,
                   0, 0, 0x34, 0, 0x0B, 0, 5, 0, 0, 0, 0x3C, 0, 0x0B, 0, 5, 1]
    else:
        fvfdata = [0, 0, 0, 0, 0x40, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0x00, 0, 0x02, 0, 0, 0, 0, 0, 0x0C, 0, 0x02, 0, 3, 0,
                   0, 0, 0x18, 0, 0x0D, 0, 1, 0, 0, 0, 0x1C, 0, 0x05, 0, 2, 0,
                   0, 0, 0x20, 0, 0x03, 0, 6, 0, 0, 0, 0x30, 0, 0x0B, 0, 5, 0,
                   0, 0, 0x38, 0, 0x0B, 0, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0]

    objdata = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               1, 0, 0, 0, 5, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x80, 0x3F, 0, 0, 0, 0,
               0, 0, 0x80, 0x3F, 0, 0, 0x80, 0x3F, 0, 0, 0, 0, 0, 0, 0, 0,
               1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
               0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x08, 0xD8, 0x24]

    objdata[0x74:0x78] = len(index_buffer).to_bytes(4, 'little') # Index Count
    objdata[0x7C:0x80] = len(convert_vertex).to_bytes(4, 'little') # Vertex Count

    part_bin.extend(geo_header)
    part_bin.extend(fvfdata)
    part_bin.extend(objdata)

    return part_bin


def check_transform(obj):

    global prop

    tolerance = 0.000001

    if prop["coordinate"] == "Global":
        matrix = obj.matrix_world
    else:
        matrix = obj.matrix_local

    loc, rot, sca = (axis_conversion(to_forward='-Z', to_up='Y').to_4x4() @ matrix).decompose()

    if (
        abs(loc[0]) > tolerance or
        abs(loc[1]) > tolerance or
        abs(loc[2]) > tolerance or
        abs(rot.to_euler()[0]) > tolerance or
        abs(rot.to_euler()[1]) > tolerance or
        abs(rot.to_euler()[2]) > tolerance
    ):
        return False
    else:
        return True


def build_bin_gmatrix(obj):

    matrix = axis_conversion(to_forward='-Z', to_up='Y').to_4x4() @ obj.matrix_world

    for i in range(0, 3):
        for j in range(0, 3):
            if round(matrix[i][j] * 100000) == 0:
                matrix[i][j] = 0

    part_bin = bytearray()
    part_bin.extend(struct.pack("<4f", matrix[0][0], matrix[1][0], matrix[2][0], matrix[3][0]))
    part_bin.extend(struct.pack("<4f", matrix[0][1], matrix[1][1], matrix[2][1], matrix[3][1]))
    part_bin.extend(struct.pack("<4f", matrix[0][2], matrix[1][2], matrix[2][2], matrix[3][2]))
    part_bin.extend(struct.pack("<4f", matrix[0][3], matrix[1][3], matrix[2][3], matrix[3][3]))

    return part_bin


def build_bin_blend_indices(blend_names):

    blenddata_main = []
    offsets = []
    offset = 0x30

    for i, name in enumerate(blend_names):
        offsets.append(offset)
        data_len = 0x10 + (len(name) + 15) // 16 * 16
        data = data_len * [0]
        data[0:4] = i.to_bytes(4, 'little')
        data[4:8] = len(name).to_bytes(4, 'little')
        data[0x10:0x10 + len(name)] = name.encode('ASCII')
        blenddata_main.extend(data)
        offset += data_len

    offsetdata_len = (len(offsets) + 3) // 4 * 16
    blenddata_offset = offsetdata_len * [0]
    for i, ofs in enumerate(offsets):
        result_ofs = offsetdata_len + ofs
        blenddata_offset[4*i:4*(i+1)] = result_ofs.to_bytes(4, 'little')

    blenddata = [0x42, 0x6C, 0x65, 0x6E, 0x64, 0x49, 0x64, 0x78, 0, 0, 1, 1, 0x30, 0, 0, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                 0x30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    blenddata[0x14:0x18] = blenddata[0x18:0x1C] = len(blend_names).to_bytes(4, 'little')
    total_len = 0x30 + len(blenddata_offset) + len(blenddata_main)
    blenddata[0x10:0x14] = total_len.to_bytes(4, 'little')

    blenddata.extend(blenddata_offset)
    blenddata.extend(blenddata_main)

    return blenddata


def build_bin_header(tmc_bin):

    headerdata = [0x74, 0x6D, 0x63, 0x6D, 0x65, 0x73, 0x68, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
                  0, 0, 0, 0, 0x11, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0,
                  0x30, 0, 0, 0, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0xD0, 0, 0, 0, 0, 0, 0, 0, 0x30, 0x02, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0x60, 0x01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    filesize = 0xD0 + sum(len(bin) for bin in tmc_bin)
    headerdata[0x10:0x14] = filesize.to_bytes(4, 'little') # File Size

    offset3  = 0xD0 + len(tmc_bin[0]) + len(tmc_bin[2])
    offset9  = 0xD0 + len(tmc_bin[0]) + len(tmc_bin[2]) + len(tmc_bin[3])
    offset15 = 0xD0 + len(tmc_bin[0]) + len(tmc_bin[2]) + len(tmc_bin[3]) + len(tmc_bin[9])
    headerdata[0x3C:0x40] = offset3.to_bytes(4, 'little') # Offset IdxLay
    if len(tmc_bin[9]) != 0: headerdata[0x54:0x58] = offset9.to_bytes(4, 'little') # Offset Global Matrix
    headerdata[0x6C:0x70] = offset15.to_bytes(4, 'little') # Offset Blend indices

    headerdata[0x88:0x8C] = len(tmc_bin[2]).to_bytes(4, 'little') # Size VtxLay
    headerdata[0x8C:0x90] = len(tmc_bin[3]).to_bytes(4, 'little') # Size IdxLay
    headerdata[0xA4:0xA8] = len(tmc_bin[9]).to_bytes(4, 'little') # Size Global Matrix
    headerdata[0xBC:0xC0] = len(tmc_bin[15]).to_bytes(4, 'little') # Size Blend indices

    return headerdata


def init_nodenames(obj, nodename):

    mot = {}

    mot["right"] = (("09","Foot"), ("10","ForeArm"), ("11","Hand"), ("12","UpLeg"), ("13","Leg"), ("14","Arm"), ("19","Shoulder"), ("20","Toe"))
    mot["left"] = (("03","Foot"), ("04","ForeArm"), ("05","Hand"), ("06","UpLeg"), ("07","Leg"), ("08","Arm"), ("17","Shoulder"), ("18","Toe"))

    mot["right_bird"] = (("09","Shoulder"), ("10","Winglfore"), ("11","Winglend_A"), ("16","UpLeg"), ("17","Leg"), ("18","Foot"), ("19","Toe"), ("20","Tail"), ("23","Winglend_B"))
    mot["left_bird"] = (("06","Shoulder"), ("07","Winglfore"), ("08","Winglend_A"), ("12","UpLeg"), ("13","Leg"), ("14","Foot"), ("15","Toe"), ("21","Tail"), ("22","Winglend_B"))

    mot["right_seagull"] = (("02","Shoulder"), ("03","Winglend_A"))
    mot["left_seagull"] = (("04","Shoulder"), ("05","Winglend_A"))

    mot["right_tiger"] = (("09","_shoulder_"), ("10","*rm_"), ("11","_forearm_"), ("12","_hand_"), ("17","_upleg_"), ("30","_ear_"), ("32","_cheek_"), ("34","_shoulderB_"))
    mot["left_tiger"] = (("05","_shoulder_"), ("06","*rm_"), ("07","_forearm_"), ("08","_hand_"), ("13","_upleg_"), ("14","_leg_"), ("15","_foot_"), ("16","_toe_"), ("29","_ear_"), ("31","_cheek_"), ("35","_shoulderB_"))

    mot["right_pig"] = (("9","upleg_"), ("10","leg_"), ("11","foot_"), ("15","arm_"), ("16","fore_"), ("17","hand_"), ("20","ear_"))
    mot["left_pig"] = (("6","upleg_"), ("7","leg_"), ("8","foot_"), ("12","arm_"), ("13","fore_"), ("14","hand_"), ("19","ear_"))

    mot["right_fla"] = (("11","arm_"), ("12","fore_"), ("13","hand_"), ("17","upleg_"), ("18","leg_"), ("19","foot_"))
    mot["left_fla"] = (("08","arm_"), ("09","fore_"), ("10","hand_"), ("14","upleg_"), ("15","leg_"), ("16","foot_"))

    mot["right_orn"] = (("23","Handfing_a_"), ("24","Handfing_b_"), ("25","Handthum_a_"), ("26","Handthum_b_"), ("31","footfing_a_"), ("32","footfing_b_"), ("33","footthum_a_"), ("34","footthum_b_"), ("36","Shoulder1_"), ("09","Foot"), ("10","ForeArm"), ("11","Hand"), ("12","UpLeg"), ("13","Leg"), ("14","Arm"), ("19","Shoulder"), ("20","Toe"))
    mot["left_orn"] = (("19","Handfing_a_"), ("20","Handfing_b_"), ("21","Handthum_a_"), ("22","Handthum_b_"), ("27","footfing_a_"), ("28","footfing_b_"), ("29","footthum_a_"), ("30","footthum_b_"), ("35","Shoulder1_"), ("03","Foot"), ("04","ForeArm"), ("05","Hand"), ("06","UpLeg"), ("07","Leg"), ("08","Arm"), ("17","Shoulder"), ("18","Toe"))



    if obj is not None:

        blend_names = []

        for v in obj.vertex_groups:
            s = v.name

            if s == "MOT_*_leg_MobA_Tiger.1.r":
                blend_names.append("MOT18_right_upleg_MobA_Tiger")
                continue
            elif s == "MOT_*_foot_MobA_Tiger.1.r":
                blend_names.append("MOT19_right_shin_MobA_Tiger")
                continue
            elif s == "MOT_*_toe_MobA_Tiger.1.r":
                blend_names.append("MOT20_right_foot_MobA_Tiger")
                continue

            s = init_nodename(s, mot)

            blend_names.append(s)

        return blend_names

    elif nodename is not None:

        changed_name = init_nodename(nodename, mot)

        return changed_name



def init_nodename(s, mot):

    if ">" in s:
        s = s.replace(">", "_Instance")

    if "*" in s:
        if "_Instance" in s:
            pass

        elif s[:3] == "MOT" and ".1.R" in s:
            mot_base = mot["right"]

            if "MobB_BIRD" in s or "MobE_BRD" in s:
                mot_base = mot["right_bird"]
            elif "MobA_SEAGULL" in s:
                mot_base = mot["right_seagull"]
            elif "MobA_Tiger" in s:
                mot_base = mot["right_tiger"]
            elif "MobB_PIG" in s:
                mot_base = mot["right_pig"]
            elif "MobA_FLA" in s:
                mot_base = mot["right_fla"]
            elif "MobB_ORN" in s:
                mot_base = mot["right_orn"]

            for i in range(len(mot_base)):
                if mot_base[i][1] in s:
                    s = s[:3] + mot_base[i][0] + s[3:]
                    break

        elif s[:3] == "MOT" and ".1.L" in s:
            mot_base = mot["left"]

            if "MobB_BIRD" in s or "MobE_BRD" in s:
                mot_base = mot["left_bird"]
            elif "MobA_SEAGULL" in s:
                mot_base = mot["left_seagull"]
            elif "MobA_Tiger" in s:
                mot_base = mot["left_tiger"]
            elif "MobB_PIG" in s:
                mot_base = mot["left_pig"]
            elif "MobA_FLA" in s:
                mot_base = mot["left_fla"]
            elif "MobB_ORN" in s:
                mot_base = mot["left_orn"]

            for i in range(len(mot_base)):
                if mot_base[i][1] in s:
                    s = s[:3] + mot_base[i][0] + s[3:]
                    break

        pos = s.find(".")
        if ".1.R" in s:
            s = s[:pos].replace("*", "Right")
        elif ".1.L" in s:
            s = s[:pos].replace("*", "Left")
        elif ".1.r" in s:
            s = s[:pos].replace("*", "right")
        elif ".1.l" in s:
            s = s[:pos].replace("*", "left")
        elif ".0.R" in s:
            s = s[:pos].replace("*", "R")
        elif ".0.L" in s:
            s = s[:pos].replace("*", "L")
        elif ".0.r" in s:
            s = s[:pos].replace("*", "r")
        elif ".0.l" in s:
            s = s[:pos].replace("*", "l")

    return s


def write_tmcmesh(obj, blend_names, filepath, mat_index):

    global prop

    import time
    start_mesh = time.time()

    ori_normals = []

    view_layer = bpy.context.view_layer

    if view_layer.objects.active is not None and view_layer.objects.active.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    for v in obj.data.vertices:
        ori_normals.append(list(v.normal))

    tri_modi = obj.modifiers.new("Triangulate", 'TRIANGULATE')
    tri_modi.show_viewport = True
    tri_modi.quad_method = 'BEAUTY'
    tri_modi.ngon_method = 'BEAUTY'

    skip_apply_modi = []
    if not prop["apply_armature_modifier"]:
        for i, m in enumerate(obj.modifiers):
            if m.type == 'ARMATURE' and m.show_viewport:
                m.show_viewport = False
                skip_apply_modi.append(i)

    depsgraph = bpy.context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    mesh = obj_eval.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    mesh_vg = mesh.copy()
    mesh = obj_eval.to_mesh()
    obj.modifiers.remove(tri_modi)

    if prop["use_loop_normals"] and mesh.use_auto_smooth:
        prop["use_loop_normals_mesh"] = True
    elif prop["use_loop_normals"] and mesh.has_custom_normals:
        prop["use_loop_normals_mesh"] = True
        mesh.use_auto_smooth = True
    else:
        prop["use_loop_normals_mesh"] = False

    for i in skip_apply_modi:
        obj.modifiers[i].show_viewport = True

    max_len = 65534
    if len(mesh.vertices) > max_len:
        error_message += obj.name + " " + str(len(mesh.vertices) - max_len) + " vertices exceeded the maximum number.\n"
        return

    new_vertices, new_faces = build_vertex_data(mesh, mesh_vg, ori_normals, mat_index)
    if new_faces is None or len(new_faces) == 0:
        return

    index_buffer = build_index_buffer(new_faces)

    tmc_bin = []
    tmc_bin.append(build_bin_geo(new_vertices, index_buffer))
    tmc_bin.append([])
    tmc_bin.append(build_bin_vertex_buffer(new_vertices))
    tmc_bin.append(build_bin_index_buffer(index_buffer))
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])

    if check_transform(obj):
        tmc_bin.append([])
    else:
        tmc_bin.append(build_bin_gmatrix(obj))

    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append([])
    tmc_bin.append(build_bin_blend_indices(blend_names))
    header_bin = build_bin_header(tmc_bin)

    obj_eval.to_mesh_clear()
    bpy.data.meshes.remove(mesh_vg)

    bin = bytearray()
    bin.extend(header_bin)

    for bn in tmc_bin:
        bin.extend(bn)

    f = open(filepath, 'wb')
    f.write(bin)
    f.close()

    elapsed_time = time.time() - start_mesh
    print("Elapsed Time: {0}".format(elapsed_time))

    del bin
    del header_bin
    del tmc_bin
    del index_buffer
    del new_faces
    del new_vertices
    del ori_normals

    gc.collect()


def save_tmcmesh(obj, blend_names, dirname, filepath):

    global prop

    mesh = obj.data

    if filepath is None:
        name = init_nodenames(None, obj.name)
        filepath = dirname + "\\" + name + ".tmcmesh"
        if not prop["overwrite"] and not (prop["separate_by_mat"] and len(mesh.materials) > 1):
            count = 1
            while os.path.exists(filepath):
                filepath = dirname + "\\" + name + " - " + str(count) + ".tmcmesh"
                count += 1

    if prop["separate_by_mat"] and len(mesh.materials) > 1:
        basepath = filepath.replace(".tmcmesh", "")
        for i, mat in enumerate(mesh.materials):
            name = init_nodenames(None, mat.name)
            filepath = basepath + "-" + name + ".tmcmesh"
            if not prop["overwrite"]:
                count = 1
                while os.path.exists(filepath):
                    filepath = basepath + "-" + name + " - " + str(count) + ".tmcmesh"
                    count += 1
            write_tmcmesh(obj, blend_names, filepath, i)

    else:
        write_tmcmesh(obj, blend_names, filepath, -1)




def get_exportable_objects():
    exportable_objects = []

    view_layer = bpy.context.view_layer

    if view_layer.objects.active is not None and not view_layer.objects.active.hide_viewport and not view_layer.objects.active.select_get():
        view_layer.objects.active.select_set(True)

    for obj in bpy.context.selected_objects:
        if obj.hide_viewport or obj.type != 'MESH' or len(obj.data.uv_layers) == 0:
            continue
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh()
        v_count = len(mesh.vertices)
        obj_eval.to_mesh_clear()
        if len(obj.data.polygons) == 0 or v_count > 65534:
            continue

        exportable_objects.append(obj)

    return exportable_objects


def get_uv_callback(self, context):
    global exportable_objects

    items = []
    if exportable_objects is None or len(exportable_objects) == 0:
        exportable_objects = get_exportable_objects()
    for i, uvlayer in enumerate(exportable_objects[0].data.uv_layers):
        item = (str(i), uvlayer.name, "")
        items.append(item)
    return items


def get_vertex_groups_callback(self, context):
    global exportable_objects

    items = []
    if exportable_objects is None or len(exportable_objects) == 0:
        exportable_objects = get_exportable_objects()
    for i, g in enumerate(exportable_objects[0].vertex_groups):
        item = (str(i), g.name, "")
        items.append(item)
    return items


class Export_tmcmesh(Operator, ExportHelper):
    """Export to tmcmesh"""
    bl_idname = "export.tmcmesh"
    bl_label = "Export tmcmesh"

    filename_ext = ".tmcmesh"

    filter_glob: StringProperty(
            default="*.tmcmesh",
            options={'HIDDEN'},
            )

    overwrite: BoolProperty(
            name="Overwrite",
            description="Overwrite Same Name File",
            default=False,
            )

    separate_by_mat: BoolProperty(
            name="Separate By Material",
            description="Export Separate tmcmesh By Material",
            default=False,
            )

    coordinate: EnumProperty(
            name="Reference Coordinate",
            items = (("Global", "Global", ""), ("Object", "Object", "")),
            default = "Global",
            description = "Reference Coordinate",
            )

    v_datasize: EnumProperty(
            name="Vertex Data Size",
            items = (("0", "0x40", ""), ("1", "0x60", ""), ("2", "0x44(Include Vertex Color)", "")),
            default = "0",
            description = "Vertex Data Size",
            )

    assign_uv1: EnumProperty(
            name="UV1",
            items = get_uv_callback,
            description = "assign UVmap in blender to UVmap1 in tmcmesh",
            )

    assign_uv2: EnumProperty(
            name="UV2",
            items = get_uv_callback,
            description = "assign UVmap in blender to UVmap2 in tmcmesh",
            )

    assign_uv3: EnumProperty(
            name="UV3",
            items = get_uv_callback,
            description = "assign UVmap in blender to UVmap3 in tmcmesh",
            )

    assign_uv4: EnumProperty(
            name="UV4",
            items = get_uv_callback,
            description = "assign UVmap in blender to UVmap4 in tmcmesh",
            )

    normalmap: EnumProperty(
            name="As Normalmap",
            items = (("0", "UV1", ""), ("1", "UV2", ""), ("2", "UV3", ""), ("3", "UV4", "")),
            default = "2",
            description = "UVmap as Normalmap",
            )

    assign_zero_weight: EnumProperty(
            name="0 Weight",
            items = get_vertex_groups_callback,
            description = "Assign Vertex Group to Vertex of Zero Weight",
            )

    apply_armature_modifier: BoolProperty(
            name="Apply Armature Modifier",
            description="Apply Armature Modifier",
            default=False,
            )

    use_loop_normals: BoolProperty(
            name="Use Loop Normals",
            description="Use Loop Normals",
            default=False,
            )

    round_uv_co: BoolProperty(
            name="Round UV Cordinate",
            description="Round UV Coordinate",
            default=False,
            )

    ignore_different_tangent: BoolProperty(
            name="Ignore Different Tangent",
            description="Ignore Different Tangent",
            default=False,
            )


    def draw(self, context):
        global exportable_objects

        if len(bpy.context.selected_objects) == 1 and not bpy.context.selected_objects[0].hide_viewport:
            obj = bpy.context.selected_objects[0]
        else:
            obj = bpy.context.active_object
        layout = self.layout
        if exportable_objects is None or len(exportable_objects) == 0:
            exportable_objects = get_exportable_objects()
        layout.label(text="Exportable / Selected : " + str(len(exportable_objects)) + " / " + str(len(bpy.context.selected_objects)))
        layout.label(text="Base Object : " + exportable_objects[0].name)
        layout.prop(self, "separate_by_mat")
        col_multiple = layout.column()
        col_multiple.prop(self, "overwrite")
        if len(bpy.context.selected_objects) == 1 and not self.separate_by_mat:
            col_multiple.enabled = False

        layout.separator()

        layout.prop(self, "coordinate", expand=True)
        layout.prop(self, "v_datasize")
        box = layout.box()
        box.prop(self, "assign_uv1")
        box.prop(self, "assign_uv2")
        box.prop(self, "assign_uv3")
        box.prop(self, "assign_uv4")
        layout.prop(self, "normalmap")
        col_vgroups = layout.column()
        if len(obj.vertex_groups) == 0:
            col_vgroups.enabled = False
        col_vgroups.prop(self, "assign_zero_weight")
        layout.prop(self, "apply_armature_modifier")
        layout.prop(self, "use_loop_normals")
        layout.prop(self, "round_uv_co")
        if ignore_different_tangent_option:
            layout.prop(self, "ignore_different_tangent")


    def execute(self, context):
        global prop
        global error_message
        global exportable_objects

        prop = {}
        prop["overwrite"] = self.overwrite
        prop["separate_by_mat"] = self.separate_by_mat
        prop["coordinate"] = self.coordinate
        prop["v_datasize"] = int(self.v_datasize)
        prop["normalmap"] = int(self.normalmap)
        prop["apply_armature_modifier"] = self.apply_armature_modifier
        prop["use_loop_normals"] = self.use_loop_normals
        prop["round_uv_co"] = self.round_uv_co
        if ignore_different_tangent_option:
            prop["ignore_different_tangent"] = self.ignore_different_tangent
        else:
            prop["ignore_different_tangent"] = False

        dirname = os.path.dirname(self.filepath)
        basename = os.path.basename(self.filepath)
        basename = re.sub(r"[\\|/|:|*|?|\"|<|>|\|]", "-", basename)
        filepath = dirname + "\\" + basename

        base_obj = exportable_objects[0]
        if self.assign_zero_weight != "":
            base_v_group = base_obj.vertex_groups[int(self.assign_zero_weight)].name

        for obj in exportable_objects:

            if int(self.assign_uv1) < len(obj.data.uv_layers):
                uv1 = int(self.assign_uv1)
            else:
                uv1 = 0
            if int(self.assign_uv2) < len(obj.data.uv_layers):
                uv2 = int(self.assign_uv2)
            else:
                uv2 = 0
            if int(self.assign_uv3) < len(obj.data.uv_layers):
                uv3 = int(self.assign_uv3)
            else:
                uv3 = 0
            if int(self.assign_uv4) < len(obj.data.uv_layers):
                uv4 = int(self.assign_uv4)
            else:
                uv4 = 0
            prop["assign_uv"] = [uv1, uv2, uv3, uv4]

            if len(obj.vertex_groups) == 0:
                prop["assign_zero_weight"] = None
                if prop["v_datasize"] == 1:
                    blend_names = ["MOT01_Head"]
                else:
                    blend_names = ["MOT00_Hips"]
            else:
                blend_names = init_nodenames(obj, None)
                if base_v_group not in obj.vertex_groups:
                    prop["assign_zero_weight"] = 0
                else:
                    prop["assign_zero_weight"] = int(self.assign_zero_weight)

            if len(exportable_objects) == 1:
                save_tmcmesh(obj, blend_names, None, filepath)
            else:
                save_tmcmesh(obj, blend_names, dirname, None)

        exportable_objects = []
        gc.collect()

        if error_message != "":
            print(error_message)
            bpy.ops.object.error_dialog_operator('INVOKE_DEFAULT')
            error_message = ""
            return {'CANCELLED'}

        return {'FINISHED'}


    def cancel(self, context):
        global exportable_objects

        exportable_objects = []

        gc.collect()

