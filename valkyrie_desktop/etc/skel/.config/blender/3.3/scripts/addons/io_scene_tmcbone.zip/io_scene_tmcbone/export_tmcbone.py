import bpy
import os
import math
import mathutils
import binascii
import struct
from operator import attrgetter
from bpy.props import *
from bpy_extras.io_utils import (
        ImportHelper,
        ExportHelper,
        orientation_helper,
        axis_conversion,
        )
from bpy.types import (
        Operator,
        OperatorFileListElement,
        )



error_message = ""

new_bones = []
bone_indices = {}

mot_right = (("09","Foot"), ("10","ForeArm"), ("11","Hand"), ("12","UpLeg"), ("13","Leg"), ("14","Arm"), ("19","Shoulder"), ("20","Toe"))
mot_left = (("03","Foot"), ("04","ForeArm"), ("05","Hand"), ("06","UpLeg"), ("07","Leg"), ("08","Arm"), ("17","Shoulder"), ("18","Toe"))

mot_right_bird = (("09","Shoulder"), ("10","Winglfore"), ("11","Winglend_A"), ("16","UpLeg"), ("17","Leg"), ("18","Foot"), ("19","Toe"), ("20","Tail"), ("23","Winglend_B"))
mot_left_bird = (("06","Shoulder"), ("07","Winglfore"), ("08","Winglend_A"), ("12","UpLeg"), ("13","Leg"), ("14","Foot"), ("15","Toe"), ("21","Tail"), ("22","Winglend_B"))

mot_right_seagull = (("02","Shoulder"), ("03","Winglend_A"))
mot_left_seagull = (("04","Shoulder"), ("05","Winglend_A"))

mot_right_tiger = (("09","_shoulder_"), ("10","*rm_"), ("11","_forearm_"), ("12","_hand_"), ("17","_upleg_"), ("30","_ear_"), ("32","_cheek_"), ("34","_shoulderB_"))
mot_left_tiger = (("05","_shoulder_"), ("06","*rm_"), ("07","_forearm_"), ("08","_hand_"), ("13","_upleg_"), ("14","_leg_"), ("15","_foot_"), ("16","_toe_"), ("29","_ear_"), ("31","_cheek_"), ("35","_shoulderB_"))

mot_right_pig = (("9","upleg_"), ("10","leg_"), ("11","foot_"), ("15","arm_"), ("16","fore_"), ("17","hand_"), ("20","ear_"))
mot_left_pig = (("6","upleg_"), ("7","leg_"), ("8","foot_"), ("12","arm_"), ("13","fore_"), ("14","hand_"), ("19","ear_"))

mot_right_fla = (("11","arm_"), ("12","fore_"), ("13","hand_"), ("17","upleg_"), ("18","leg_"), ("19","foot_"))
mot_left_fla = (("08","arm_"), ("09","fore_"), ("10","hand_"), ("14","upleg_"), ("15","leg_"), ("16","foot_"))

mot_right_orn = (("23","Handfing_a_"), ("24","Handfing_b_"), ("25","Handthum_a_"), ("26","Handthum_b_"), ("31","footfing_a_"), ("32","footfing_b_"), ("33","footthum_a_"), ("34","footthum_b_"), ("36","Shoulder1_"), ("09","Foot"), ("10","ForeArm"), ("11","Hand"), ("12","UpLeg"), ("13","Leg"), ("14","Arm"), ("19","Shoulder"), ("20","Toe"))
mot_left_orn = (("19","Handfing_a_"), ("20","Handfing_b_"), ("21","Handthum_a_"), ("22","Handthum_b_"), ("27","footfing_a_"), ("28","footfing_b_"), ("29","footthum_a_"), ("30","footthum_b_"), ("35","Shoulder1_"), ("03","Foot"), ("04","ForeArm"), ("05","Hand"), ("06","UpLeg"), ("07","Leg"), ("08","Arm"), ("17","Shoulder"), ("18","Toe"))



class NewBone():
    __slots__ = (
        "name",
        "matrix",
        "parent",
        "children",
        "bonelevel"
        )

    def __init__(self, bone):
        self.name = reset_bone_name(bone)
        self.children = []


class DialogOperator(Operator):
    bl_idname = "object.dialog_operator"
    bl_label = "A problem occurred."
    def execute(self, context):
        self.report({'ERROR'}, error_message)
        return {'FINISHED'}
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)



def build_bone_data(obj):

    global error_message
    global new_bones
    global bone_indices

    new_bones = []
    bone_indices = {}

    def add_bone_data(bone, parent):

        global new_bones

        new_bone = NewBone(bone)
        new_bones.append(new_bone)
        new_bone.parent = parent
        new_bone.bonelevel = len(bone.parent_recursive)
        for child in bone.children:
            new_bone.children.append(add_bone_data(child, new_bone))
        new_bone.matrix = bone.matrix

        return new_bone

    for bone in obj.data.edit_bones:
        if bone.parent is None:
            add_bone_data(bone, None)

    new_bones.sort(key=lambda x:x.name.lower())

    mat_rot_z180nega = mathutils.Matrix.Rotation(math.radians(-180.0), 4, 'Z')
    mat_rot_z90nega = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'Z')
    mat_rot_z270nega = mathutils.Matrix.Rotation(math.radians(-270.0), 4, 'Z')
    mat_rot_x90nega = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')

    for i, bone in enumerate(new_bones):
        bone_indices[bone.name] = i
        part = ""
        if bone.name != "MOT00_Hips" and bone.name != "MOT16_Waist" and bone.name != "MOT02_Chest" and bone.name != "MOT15_Neck" and bone.name != "MOT01_Head":
            parent = bone.parent
            while parent is not None and parent.name != "MOT00_Hips":
                if parent.name == "MOT17_LeftShoulder" or bone.name == "MOT17_LeftShoulder":
                    part = "LeftArm"
                    break
                elif parent.name == "MOT19_RightShoulder" or bone.name == "MOT19_RightShoulder":
                    part = "RightArm"
                    break
                elif "WGT_acs_" in parent.name:
                    break;
                elif "MOT15_Neck" in parent.name:
                    break;
                elif "OPT_Face_" in bone.name:
                    part = "Face"
                    break
                elif "OPT_Breast_" in bone.name:
                    part = "Breast"
                    break
                else:
                    parent = parent.parent
            if part == "LeftArm":
                bone.matrix = bone.matrix @ mat_rot_z270nega
            elif part == "RightArm":
                bone.matrix = bone.matrix @ mat_rot_z90nega
            elif part == "Breast":
                bone.matrix = bone.matrix @ mat_rot_x90nega
            elif part == "Face":
                bone.matrix = bone.matrix @ mat_rot_x90nega
            else:
                bone.matrix = bone.matrix @ mat_rot_z180nega

        for j in range(4):
            for k in range(3):
                if abs(bone.matrix[j][k]) < 0.000001:
                    bone.matrix[j][k] = 0


def build_bin_hielay():

    global new_bones

    bin = [0x48, 0x69, 0x65, 0x4C, 0x61, 0x79, 0, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0x30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    bin[0x14:0x18] = len(new_bones).to_bytes(4, 'little')
    bin[0x18:0x1C] = len(new_bones).to_bytes(4, 'little')

    bin.extend([0] * (4 * ((len(new_bones) + 3) // 4 * 4)))

    bin[0x28:0x2C] = len(bin).to_bytes(4, 'little')
    bin.extend(struct.pack('<i', 1))
    bin.extend([0] * 0x0C)

    for i, bone in enumerate(new_bones):
        if bone.bonelevel == 0:
            bin.extend(struct.pack('<i', i))
            bin.extend([0] * 0x0C)
            break

    for i, bone in enumerate(new_bones):
        bin[0x30 + (4 * i):0x34 + (4 * i)] = len(bin).to_bytes(4, 'little') # Offset
        parent = -1
        if bone.parent is not None:
            matrix = (new_bones[bone_indices[bone.parent.name]].matrix.inverted_safe() @ bone.matrix).transposed()
            parent = bone_indices[bone.parent.name]
        else:
            matrix = bone.matrix.transposed()

        bin.extend(struct.pack('<4f', *matrix[0]))
        bin.extend(struct.pack('<4f', *matrix[1]))
        bin.extend(struct.pack('<4f', *matrix[2]))
        bin.extend(struct.pack('<4f', *matrix[3]))

        bin.extend(struct.pack('<i', parent))
        bin.extend(struct.pack('<i', len(bone.children)))
        bin.extend(struct.pack('<i', bone.bonelevel))
        bin.extend(struct.pack('<i', 0))
        for child in bone.children:
            bin.extend(struct.pack('<i', bone_indices[child.name]))
        if len(bin) % 16 != 0:
            bin.extend([0] * (16 - (len(bin) % 16)))

    bin[0x10:0x14] = len(bin).to_bytes(4, 'little')

    return bin


def build_bin_nodelay():

    global new_bones

    bin = [0x4E, 0x6F, 0x64, 0x65, 0x4C, 0x61, 0x79, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0x40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    bin[0x14:0x18] = len(new_bones).to_bytes(4, 'little')
    bin[0x18:0x1C] = len(new_bones).to_bytes(4, 'little')

    bin.extend([0] * (4 * ((len(new_bones) + 3) // 4 * 4)))

    for i, bone in enumerate(new_bones):
        bin[0x40 + (4 * i):0x44 + (4 * i)] = len(bin).to_bytes(4, 'little') # Offset

        node_bin = [0x4E, 0x6F, 0x64, 0x65, 0x4F, 0x62, 0x6A, 0, 0, 0, 1, 1, 0x30, 0, 0, 0]
        node_bin.extend([0] * 0x24)
        node_bin.extend(struct.pack('<i', -1))
        node_bin.extend(struct.pack('<i', i))
        node_bin.extend(struct.pack('<i', 0))
        node_bin.extend(bone.name.encode('ASCII'))
        node_bin.extend([0] * (16 - (len(node_bin) % 16)))
        node_bin[0x10:0x14] = len(node_bin).to_bytes(4, 'little')

        bin.extend(node_bin)

    bin[0x10:0x14] = len(bin).to_bytes(4, 'little')

    return bin


def build_bin_glblmtx():

    global new_bones

    bin = [0x47, 0x6C, 0x62, 0x6C, 0x4D, 0x74, 0x78, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0x30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    bin[0x14:0x18] = len(new_bones).to_bytes(4, 'little')
    bin[0x18:0x1C] = len(new_bones).to_bytes(4, 'little')

    bin.extend([0] * (4 * ((len(new_bones) + 3) // 4 * 4)))

    for i, bone in enumerate(new_bones):
        bin[0x30 + (4 * i):0x34 + (4 * i)] = len(bin).to_bytes(4, 'little') # Offset
        matrix = bone.matrix.transposed()
        bin.extend(struct.pack('<4f', *matrix[0]))
        bin.extend(struct.pack('<4f', *matrix[1]))
        bin.extend(struct.pack('<4f', *matrix[2]))
        bin.extend(struct.pack('<4f', *matrix[3]))

    bin[0x10:0x14] = len(bin).to_bytes(4, 'little')

    return bin


def build_bin_bnofsmtx():

    global new_bones

    bin = [0x42, 0x6E, 0x4F, 0x66, 0x73, 0x4D, 0x74, 0x78, 0, 0, 1, 1, 0x30, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0x30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    bin[0x14:0x18] = len(new_bones).to_bytes(4, 'little')
    bin[0x18:0x1C] = len(new_bones).to_bytes(4, 'little')

    bin.extend([0] * (4 * ((len(new_bones) + 3) // 4 * 4)))

    for i, bone in enumerate(new_bones):
        bin[0x30 + (4 * i):0x34 + (4 * i)] = len(bin).to_bytes(4, 'little') # Offset
        matrix = bone.matrix.inverted_safe().transposed()

        for j in range(4):
            for k in range(4):
                if abs(matrix[j][k]) == 0:
                    matrix[j][k] = 0

        bin.extend(struct.pack('<4f', *matrix[0]))
        bin.extend(struct.pack('<4f', *matrix[1]))
        bin.extend(struct.pack('<4f', *matrix[2]))
        bin.extend(struct.pack('<4f', *matrix[3]))

    bin[0x10:0x14] = len(bin).to_bytes(4, 'little')

    return bin


def build_bin_header(tmc_bin):

    headerdata = [0x74, 0x6D, 0x63, 0x62, 0x6F, 0x6E, 0x65, 0, 0, 0, 1, 1, 0x30, 0, 0, 0,
                  0, 0, 0, 0, 0x11, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0,
                  0x30, 0, 0, 0, 0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    headerdata.extend([0] * 0xA0)

    return headerdata


def reset_bone_name(bone):
    global mot_right
    global mot_right_bird
    global mot_right_seagull
    global mot_right_tiger
    global mot_right_pig
    global mot_right_fla
    global mot_right_orn
    global mot_left
    global mot_left_bird
    global mot_left_seagull
    global mot_left_tiger
    global mot_left_pig
    global mot_left_fla
    global mot_left_orn

    s = bone.name

    if s == "MOT_*_leg_MobA_Tiger.1.r":
        return "MOT18_right_upleg_MobA_Tiger"
    elif s == "MOT_*_foot_MobA_Tiger.1.r":
        return "MOT19_right_shin_MobA_Tiger"
    elif s == "MOT_*_toe_MobA_Tiger.1.r":
        return "MOT20_right_foot_MobA_Tiger"

    if ">" in s:
        s = s.replace(">", "_Instance")

    if "*" in s:
        if "_Instance" in s:
            pass

        elif s[:3] == "MOT" and (".1.R" in s or ".1.r" in s):
            mot = mot_right

            if "MobB_BIRD" in s or "MobE_BRD" in s:
                mot = mot_right_bird
            elif "MobA_SEAGULL" in s:
                mot = mot_right_seagull
            elif "MobA_Tiger" in s:
                mot = mot_right_tiger
            elif "MobB_PIG" in s:
                mot = mot_right_pig
            elif "MobA_FLA" in s:
                mot = mot_right_fla
            elif "MobB_ORN" in s:
                mot = mot_right_orn

            for i in range(len(mot)):
                if mot[i][1] in s:
                    s = s[:3] + mot[i][0] + s[3:]
                    break

        elif s[:3] == "MOT" and (".1.L" in s or ".1.l"):
            mot = mot_left

            if "MobB_BIRD" in s or "MobE_BRD" in s:
                mot = mot_left_bird
            elif "MobA_SEAGULL" in s:
                mot = mot_left_seagull
            elif "MobA_Tiger" in s:
                mot = mot_left_tiger
            elif "MobB_PIG" in s:
                mot = mot_left_pig
            elif "MobA_FLA" in s:
                mot = mot_left_fla
            elif "MobB_ORN" in s:
                mot = mot_left_orn

            for i in range(len(mot)):
                if mot[i][1] in s:
                    s = s[:3] + mot[i][0] + s[3:]
                    break

        pos = s.find(".")
        if ".1.R" in s:
            s = s[:pos].replace("*", "Right")
        elif ".1.L" in s:
            s = s[:pos].replace("*", "Left")
        elif ".1.r" in s:
            s = s[:pos].replace("*", "right")
        elif ".1.l" in s:
            s = s[:pos].replace("*", "left")
        elif ".0.R" in s:
            s = s[:pos].replace("*", "R")
        elif ".0.L" in s:
            s = s[:pos].replace("*", "L")
        elif ".0.r" in s:
            s = s[:pos].replace("*", "r")
        elif ".0.l" in s:
            s = s[:pos].replace("*", "l")

    return s


class Export_tmcbone(bpy.types.Operator, ExportHelper):
    """Export to tmcbone"""
    bl_idname = "export.tmcbone"
    bl_label = "Export tmcbone"

    filename_ext = ".tmcbone"

    filter_glob: StringProperty(
            default="*.tmcbone",
            options={'HIDDEN'},
            )

    def draw(self, context):
        if len(bpy.context.selected_objects) == 1 and not bpy.context.selected_objects[0].hide_viewport:
            obj = bpy.context.selected_objects[0]
        else:
            obj = bpy.context.active_object
        layout = self.layout

    def execute(self, context):

        global error_message

        if len(bpy.context.selected_objects) == 1 and not bpy.context.selected_objects[0].hide_viewport:
            obj = bpy.context.selected_objects[0]
            bpy.context.view_layer.objects.active = obj
        else:
            obj = bpy.context.active_object

        if obj.type != 'ARMATURE':
            error_message = "There is No Selected Armature."
            bpy.ops.object.dialog_operator('INVOKE_DEFAULT')
            return {'CANCELLED'}

        if obj.hide_viewport:
            error_message = "Selected Armature is Hidden."
            bpy.ops.object.dialog_operator('INVOKE_DEFAULT')
            return {'CANCELLED'}

        if bpy.context.view_layer.objects.active.mode != 'EDIT': bpy.ops.object.mode_set(mode='EDIT')

        build_bone_data(bpy.context.active_object)

        bpy.ops.object.mode_set(mode='OBJECT')

        tmc_bin = []
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append(build_bin_hielay())
        tmc_bin.append([])
        tmc_bin.append(build_bin_nodelay())
        tmc_bin.append(build_bin_glblmtx())
        tmc_bin.append(build_bin_bnofsmtx())
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        tmc_bin.append([])
        header_bin = build_bin_header(tmc_bin)

        bin = bytearray()
        bin.extend(header_bin)

        for i, bn in enumerate(tmc_bin):
            if len(bn) != 0:
                bin[0x30 + (4 * i):0x34 + (4 * i)] = len(bin).to_bytes(4, 'little') # Offset
                bin[0x80 + (4 * i):0x84 + (4 * i)] = len(bn).to_bytes(4, 'little') # Size
            bin.extend(bn)
        bin[0x10:0x14] = len(bin).to_bytes(4, 'little')

        f = open(self.filepath, 'wb')
        f.write(bin)
        f.close()

        return {'FINISHED'}

