
bl_info = {
    "name": "Import-Export tmcbone (.tmcbone)",
    "author": "dtk mnr",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "File > Import-Export",
    "description": "Import-Export tmcbone",
    "warning": "",
    "category": "Import-Export",
}

if "bpy" in locals():
    import importlib
    if "import_tmcbone" in locals():
        importlib.reload(import_tmcbone)
    if "export_tmcbone" in locals():
        importlib.reload(export_tmcbone)
else:
    from . import import_tmcbone
    from . import export_tmcbone

import bpy
import os

def menu_func_import(self, context):
    self.layout.operator(import_tmcbone.Import_tmcbone.bl_idname, text="tmcbone (.tmcbone)", icon='PLUGIN')

def menu_func_export(self, context):
    if len(bpy.context.selected_objects) == 1 and not bpy.context.selected_objects[0].hide_viewport and bpy.context.selected_objects[0].type == 'ARMATURE':
        default_path = bpy.context.selected_objects[0].name.replace("_armature", "") + ".tmcbone"
    elif len(bpy.context.selected_objects) < 2 and bpy.context.active_object is not None and not bpy.context.active_object.hide_viewport and bpy.context.active_object.type == 'ARMATURE':
        default_path = bpy.context.active_object.name.replace("_armature", "") + ".tmcbone"
    else:
        return {'CANCELLED'}
    self.layout.operator(export_tmcbone.Export_tmcbone.bl_idname, text="tmcbone (.tmcbone)", icon='PLUGIN').filepath = default_path


classes = (
    import_tmcbone.Import_tmcbone,
    export_tmcbone.Export_tmcbone,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)

if __name__=="__main__":
    register()
