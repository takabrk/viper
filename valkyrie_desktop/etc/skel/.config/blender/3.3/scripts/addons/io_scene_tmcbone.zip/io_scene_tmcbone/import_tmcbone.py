import bpy
import os
import math
import mathutils
from mathutils import Vector, Matrix
import binascii
import struct
import array
from bpy.props import *
from bpy_extras.io_utils import (
        ImportHelper,
        ExportHelper,
        orientation_helper,
        axis_conversion,
        )
from bpy.types import (
        Operator,
        OperatorFileListElement,
        )



error_message = ""

prop = {}



class DialogOperator(Operator):
    bl_idname = "object.dialog_operator"
    bl_label = "A problem occurred."
    def execute(self, context):
        self.report({'ERROR'}, error_message)
        return {'FINISHED'}
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)


fglb = {'ENDIAN':'<'}#'file' = filehandle
def fread(offset = -1, fmt = 'L', extractifsingle = True):
    global fglb
    if type(offset) is str:
        if type(fmt) is bool:
            extractifsingle = fmt
        fmt = offset
    elif offset != -1:
        fglb['FILE'].seek(offset)
    result = struct.unpack(fglb['ENDIAN'] + fmt, fglb['FILE'].read(struct.calcsize("!"+fmt)))
    if extractifsingle and len(result) == 1:
        return result[0]
    return result

def freadstring(offset = -1, maxbytes = 255):
    global fglb
    if offset != -1:
        fglb['FILE'].seek(offset)
    mahbytes = b''
    count = 0
    while True:
        count += 1
        chr = fglb['FILE'].read(1)
        mahbytes += chr
        if len(chr) == 0 or count == maxbytes:
            return mahbytes[:].decode('ASCII')
        elif mahbytes[-1] == 0:
            return mahbytes[:-1].decode('ASCII')


class TmcHead():
    global fglb
    name = ''
    Size = Count1 = Count2 = Offset1 = Offset2 = Offset3 = base = 0
    offsets = []
    sizes = []
    def __init__(self, base):
        fglb['FILE'].seek(base)
        self.name = freadstring(base)
        self.Size, self.Count1, self.Count2, self.Count3, self.Offset1, self.Offset2, self.Offset3 = fread(base + 0x10, '7L')
        self.base = base
        fglb['FILE'].seek(base + self.Offset1)
        self.offsets = [fread('L') for i in range(self.Count1)]
        if self.Offset2 != 0:
            fglb['FILE'].seek(base + self.Offset2)
            self.sizes = [fread('L') for i in range(self.Count1)]


class TmcData():
    __slots__ = ("HieLay",
                 "HieMtxLayered",
                 "maxBoneLevel",
                 "MtxGrp",
                 "BnOfsMtxGrp",
                 "Nodes",
                 "MeshNodes")

    indices = []

    icount = 0

    def __init__(self, h):
        self.parseHieLay(h.offsets[6])
        self.parseGlblMtx(h.offsets[9])
        self.parseBnOfsMtx(h.offsets[10])
        self.parseNodeLay(h.offsets[8])

    def parseHieLay(self, base):
        self.HieLay = []
        self.HieMtxLayered = {}
        self.maxBoneLevel = 0
        h = TmcHead(base)
        self.maxBoneLevel = 0;
        for offs in h.offsets:
            fglb['FILE'].seek(base + offs)
            hmatrix = Matrix([fread('4f') for i in range(4)]).transposed()
            parent, chlidrencount, bonelevel, bone_ukn02 = fread(base + offs + 16 * 4, 'i3L')
            bchildren = fread(base + offs + 16 * 4 + 4 * 4, '%dL'%chlidrencount, False)
            self.HieLay.append((parent, bchildren, bonelevel, hmatrix));
            if bonelevel > self.maxBoneLevel: self.maxBoneLevel = bonelevel

    def parseGlblMtx(self, base):
        self.MtxGrp = []
        h = TmcHead(base)
        for offs in h.offsets:
            fglb['FILE'].seek(base + offs)
            gmatrix = Matrix([fread('4f') for i in range(4)]).transposed()
            self.MtxGrp.append(gmatrix)

    def parseBnOfsMtx(self, base):
        self.BnOfsMtxGrp = []
        h = TmcHead(base)
        for offs in h.offsets:
            fglb['FILE'].seek(base + offs)
            gmatrix = Matrix([fread('4f') for i in range(4)]).transposed()
            self.BnOfsMtxGrp.append(gmatrix)

    def parseNodeLay(self, base):
        self.Nodes = []
        self.MeshNodes = {}
        h = TmcHead(base)
        for offidx ,offs in enumerate(h.offsets):
            nodebase = base + offs
            unk0_0, master, index, unk0_1 = fread(nodebase + 0x30, '4l')
            original_nodename = freadstring(nodebase + 0x40)
            nodename = change_nodename(original_nodename)
            self.Nodes.append(nodename)
            mtxdataoffs = fread(nodebase + fread(nodebase + 0x20), '%dL'%fread(nodebase + 0x14), False)
            #parent, bChildren, boneLevel, hMatrix = self.HieLay[index]
            gmatrix = self.MtxGrp[index]
            if master == -1:
                for mtxoffs in mtxdataoffs:
                    objidx, childrennum, nodeidx, unk00 = fread(nodebase + mtxoffs, '4L')
                    fglb['FILE'].seek(nodebase + mtxoffs + 4 * 4)
                    #nMatrix = Matrix([fread('4f') for i in range(4)]).transposed()
                    bonegroups = fread(nodebase + mtxoffs + 4 * 4 + 16 * 4, '%dL'%childrennum, False)
                    self.MeshNodes[objidx] = (nodename, gmatrix, bonegroups, original_nodename)


def create_armature(filename, tmcdata):

    global prop

    # Create Armature
    view_layer = bpy.context.view_layer

    amt = bpy.data.armatures.new(filename + "_armature")
    obj = bpy.data.objects.new(amt.name, amt)
    obj.show_in_front = True
    amt.display_type = 'STICK' #'OCTAHEDRAL','STICK','BBONE','ENVELOPE','WIRE'
    global_matrix = axis_conversion(to_forward='Z', to_up='-Y').to_4x4()

    bpy.context.scene.collection.objects.link(obj)

    view_layer.objects.active = obj

    mat_rot_z180 = mathutils.Matrix.Rotation(math.radians(180.0), 4, 'Z')
    mat_rot_z90 = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'Z')
    mat_rot_z270 = mathutils.Matrix.Rotation(math.radians(270.0), 4, 'Z')
    mat_rot_x90 = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')

    OffsetMatrix = {}

    # Create Bones
    bpy.ops.object.mode_set(mode='EDIT')
    for i in range(tmcdata.maxBoneLevel + 1):
        for hidx, (parentidx, bchildren, bonelevel, hmatrix) in enumerate(tmcdata.HieLay):
            if bonelevel == i:
                bonename = tmcdata.Nodes[hidx]
                bone = amt.edit_bones.new(bonename)
                bone.tail += Vector((0,0,0.02))

                if parentidx != -1:
                    if tmcdata.Nodes[parentidx] in amt.edit_bones:
                        parent = amt.edit_bones[tmcdata.Nodes[parentidx]]
                        bone.parent = parent
                        if prop["bone_by"] == 0:
                            bone.matrix = tmcdata.MtxGrp[hidx]
                        elif prop["bone_by"] == 1:
                            bone.matrix = parent.matrix @ hmatrix
                            tmcdata.HieMtxLayered[hidx] = bone.matrix
                        else:
                            bone.matrix = tmcdata.BnOfsMtxGrp[hidx].inverted_safe()
                    if prop["bring_close"]:
                        for childidx in bchildren:
                            if "Shoulder" in tmcdata.Nodes[childidx]:
                                continue
                            if ("MOT" in bonename and "MOT" in tmcdata.Nodes[childidx]) or ("OPT_Hand_" in bonename and not ("_Metacarpal" in bonename or "_Root" in bonename)):
                                OffsetMatrix[bonename] = tmcdata.HieLay[childidx][3]
                else:
                    if prop["bone_by"] == 0:
                        bone.matrix = tmcdata.MtxGrp[hidx]
                    elif prop["bone_by"] == 1:
                        bone.matrix = hmatrix
                        tmcdata.HieMtxLayered[hidx] = hmatrix
                    else:
                        bone.matrix = tmcdata.BnOfsMtxGrp[hidx].inverted_safe()

    for bone in amt.edit_bones:
        part = ""
        if bone.name != "MOT00_Hips" and bone.name != "MOT16_Waist" and bone.name != "MOT02_Chest" and bone.name != "MOT15_Neck" and bone.name != "MOT01_Head":
            parent = bone.parent
            while parent is not None and parent.name != "MOT00_Hips":
                if parent.name == "MOT_*Shoulder.1.L" or bone.name == "MOT_*Shoulder.1.L":
                    part = "LeftArm"
                    break
                elif parent.name == "MOT_*Shoulder.1.R" or bone.name == "MOT_*Shoulder.1.R":
                    part = "RightArm"
                    break
                elif ("MOT_*Arm" in bone.name or "MOT_*Arm" in parent.name) and ".1.L" in bone.name:
                    part = "LeftArm"
                    break
                elif ("MOT_*Arm" in bone.name or "MOT_*Arm" in parent.name) and ".1.R" in bone.name:
                    part = "RightArm"
                    break
                elif "WGT_acs_" in parent.name:
                    break;
                elif "MOT15_Neck" in parent.name:
                    break;
                elif "OPT_Face_" in bone.name:
                    part = "Face"
                    break
                elif "OPT_Breast_" in bone.name:
                    part = "Breast"
                    break
                else:
                    parent = parent.parent
            if part == "LeftArm":
                bone.matrix = bone.matrix @ mat_rot_z270
            elif part == "RightArm":
                bone.matrix = bone.matrix @ mat_rot_z90
            elif part == "Breast":
                bone.matrix = bone.matrix @ mat_rot_x90
            elif part == "Face":
                bone.matrix = bone.matrix @ mat_rot_x90
                bone.length *= 0.25
            else:
                bone.matrix = bone.matrix @ mat_rot_z180
        if bone.name in OffsetMatrix:
            if part == "LeftArm":
                OffsetMatrix[bone.name][1][3] = OffsetMatrix[bone.name][0][3]
            elif part == "RightArm":
                OffsetMatrix[bone.name][1][3] = - OffsetMatrix[bone.name][0][3]
            elif OffsetMatrix[bone.name][1][3] < 0:
                OffsetMatrix[bone.name][1][3] *= -1
            if OffsetMatrix[bone.name][1][3] != 0:
                OffsetMatrix[bone.name][0][3] = 0
                OffsetMatrix[bone.name][2][3] = 0
                bone.tail = (bone.matrix @ OffsetMatrix[bone.name]).decompose()[0]
        if bone.parent is not None and bone.head == bone.parent.tail:
            bone.use_connect = True

    bpy.ops.object.mode_set(mode='OBJECT')
    obj.matrix_world = global_matrix


def posebone_convert_to_euler(obj):

    for bone in obj.pose.bones:

        if posebone_check_skip(bone.name):
            continue

        if "OPT_Face_" in bone.name:
            bone.rotation_mode = 'ZXY'
        elif "OPT_Hand_*_Root" in bone.name:
            bone.rotation_mode = 'ZYX'
        elif "Shoulder.1" in bone.name or "Arm.1" in bone.name or "Hand.1" in bone.name:
            bone.rotation_mode = 'YXZ'
        else:
            bone.rotation_mode = 'XYZ'


def posebone_check_skip(name):
    if name[:3] == "MOT" or "OPT_Face_" in name or "OPT_Hand_" in name or "OPT_wing" in name:
        return False
    return True


def set_offset_matrix(tmcdata):

    bpy.ops.object.mode_set(mode='POSE')

    for bone in bpy.context.visible_pose_bones:
        if bone.name in tmcdata.Nodes:
            idx = tmcdata.Nodes.index(bone.name)
            bone.matrix = tmcdata.BnOfsMtxGrp[idx] @ tmcdata.HieMtxLayered[idx] @ bone.matrix
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.poselib.new()
    bpy.ops.poselib.pose_add()
    bpy.ops.poselib.pose_rename(name="BnOfsMtx")


def change_nodename(nodename):
    s = nodename

    if s == "MOT18_right_upleg_MobA_Tiger":
        return "MOT_*_leg_MobA_Tiger.1.r"
    elif s == "MOT19_right_shin_MobA_Tiger":
        return "MOT_*_foot_MobA_Tiger.1.r"
    elif s == "MOT20_right_foot_MobA_Tiger":
        return "MOT_*_toe_MobA_Tiger.1.r"

    if "_Instance" in s:
        s = s.replace("_Instance", ">")
    if ">" not in s and s[:3] == "MOT" and ("Right" in s or "Left" in s or "right" in s or "left" in s):
        if s[4] == "_":
            s = "MOT_" + s[5:]
        else:
            s = "MOT" + s[5:]
    if "Right" in s:
        s = s.replace("Right", "*") + ".1.R"
    elif "Left" in s:
        s = s.replace("Left", "*") + ".1.L"
    elif "right" in s:
        s = s.replace("right", "*") + ".1.r"
    elif "left" in s:
        s = s.replace("left", "*") + ".1.l"
    elif "_R_" in s:
        s = s.replace("_R_", "_*_") + ".0.R"
    elif "_L_" in s:
        s = s.replace("_L_", "_*_") + ".0.L"
    elif "_r_" in s:
        s = s.replace("_r_", "_*_") + ".0.r"
    elif "_l_" in s:
        s = s.replace("_l_", "_*_") + ".0.l"
    else:
        s = s

    return s


def import_tmcbone(filepath):

    global prop

    with open(filepath, 'rb') as f:

        fglb['FILE'] = f
        view_layer = bpy.context.view_layer

        filename = os.path.splitext((os.path.basename(filepath)))[0]

        tmcH = TmcHead(0)
        if tmcH.name != "tmcbone":
            return

        tmcdata = TmcData(tmcH)

        if view_layer.objects.active != None:
            hidden = False
            if view_layer.objects.active.hide_viewport:
                view_layer.objects.active.hide_viewport = False
                hidden = True
            if view_layer.objects.active.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            if hidden:
                view_layer.objects.active.hide_viewport = True

        create_armature(filename, tmcdata)

        armature = view_layer.objects.active

        posebone_convert_to_euler(armature)

        if prop["test_offset_matrix"] and prop["bone_by"] == 1:
            set_offset_matrix(tmcdata)

        bpy.ops.object.select_all(action='DESELECT')
        view_layer.objects.active = armature
        armature.select_set(True)



class Import_tmcbone(bpy.types.Operator, ImportHelper):
    """Import to tmcbone"""
    bl_idname = "import.tmcbone"
    bl_label = "Import tmcbone"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".tmcbone"

    filter_glob: StringProperty(
            default="*.tmcbone",
            options={'HIDDEN'},
            )

    files: CollectionProperty(
            name="File Path",
            type=OperatorFileListElement,
            )

    directory: StringProperty(
            subtype='DIR_PATH',
            )

    bone_by: EnumProperty(
            name="Bone by",
            items = (("0", "GlblMtx", ""), ("1", "HieLay", ""), ("2", "BnOfsMtx", "")),
            default = "1",
            description = "Bone by",
            )

    bring_close: BoolProperty(
            name="Bring tail close to child",
            description="Bring tail of major bone close to child",
            default=True,
            )

    test_offset_matrix: BoolProperty(
            name="BnOfsMtx Test",
            description="BnOfsMtx Test",
            default=False,
            )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "bone_by")
        layout.prop(self, "bring_close")
        layout.prop(self, "test_offset_matrix")

    def execute(self, context):
        global prop

        prop = {}
        prop["bone_by"] = int(self.bone_by)
        prop["bring_close"] = self.bring_close
        prop["test_offset_matrix"] = self.test_offset_matrix

        for file in self.files:
            import_tmcbone(self.directory + "\\" + file.name)
        if len(self.files) == 0:
            import_tmcbone(self.filepath)

        return {"FINISHED"}
